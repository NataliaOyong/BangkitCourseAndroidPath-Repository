package com.example.dicodingapp.ui

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.navigation.fragment.findNavController
import com.example.dicodingapp.data.response.ListEventsItem
import com.example.dicodingapp.databinding.FragmentFinisedBinding

class FinishedFragment : Fragment() {

    private var _binding: FragmentFinisedBinding? = null
    private val binding get() = _binding!!
    private lateinit var eventViewModel: EventViewModel
    private lateinit var eventAdapter: EventAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFinisedBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        eventAdapter = EventAdapter(listOf(), { event -> openEventDetail(event) }, useAlternateLayout = true)

        binding.rvEvents.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = eventAdapter
        }

        eventViewModel = ViewModelProvider(this)[EventViewModel::class.java]

        eventViewModel.isLoading.observe(viewLifecycleOwner) { isLoading ->
            binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        }

        eventViewModel.finishedEvents.observe(viewLifecycleOwner) { eventList ->
            Log.d("FinishedFragment", "Received events: $eventList")
            eventAdapter.updateEvents(eventList)
        }

        eventViewModel.errorMessage.observe(viewLifecycleOwner) { errorMessage ->
            errorMessage?.let {
                Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            }
        }

        eventViewModel.fetchFinishedEvents(requireContext())
    }

    private fun openEventDetail(event: ListEventsItem) {
        event.id?.let { eventId ->
            val action = FinishedFragmentDirections.actionNavigationFinisedToEventDetailFragment(eventId.toString())
            findNavController().navigate(action)
        } ?: run {
            Log.e("FinishedFragment", "Event ID is null for event: ${event.name}")
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
