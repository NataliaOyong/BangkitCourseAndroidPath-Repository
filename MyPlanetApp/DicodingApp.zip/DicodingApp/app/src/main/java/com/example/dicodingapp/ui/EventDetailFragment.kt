package com.example.dicodingapp.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.text.HtmlCompat
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.navArgs
import com.bumptech.glide.Glide
import com.example.dicodingapp.databinding.FragmentEventDetailBinding
import com.example.dicodingapp.data.response.Event

class EventDetailFragment : Fragment() {

    private var _binding: FragmentEventDetailBinding? = null
    private val binding get() = _binding!!
    private lateinit var eventViewModel: EventDetailViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentEventDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val args: EventDetailFragmentArgs by navArgs()
        val eventId = args.eventId

        eventViewModel = ViewModelProvider(this)[EventDetailViewModel::class.java]
        eventViewModel.getEventDetail(eventId)

        eventViewModel.eventDetail.observe(viewLifecycleOwner) { detailEventResponse ->
            detailEventResponse?.event?.let { displayEventDetails(it) }
        }
        eventViewModel.isLoading.observe(viewLifecycleOwner) { isLoading ->
            showLoading(isLoading)
        }
    }

    private fun displayEventDetails(event: Event) {
        binding.eventName.text = event.name ?: "N/A"
        binding.ownerName.text = event.ownerName ?: "N/A"
        binding.beginTime.text = event.beginTime ?: "N/A"
        binding.description.text = event.description ?: "No description available"

        binding.description.text = HtmlCompat.fromHtml(
            event.description ?: "No description available",
            HtmlCompat.FROM_HTML_MODE_LEGACY
        )

        Glide.with(this)
            .load(event.mediaCover)
            .into(binding.imageLogo)

        binding.linkButton.setOnClickListener {
            event.link?.let { link -> openLink(link) }
        }
    }

    private fun openLink(link: String) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse(link)
        }
        startActivity(intent)
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}